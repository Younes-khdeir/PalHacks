# PalHacks
A pioneering startup that strives to find smart solutions to the problems that guide us

